package com.github.JLQusername.product.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.JLQusername.api.NetValue;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface NetValueMapper extends BaseMapper<NetValue> {
}
