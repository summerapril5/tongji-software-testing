package com.github.JLQusername.account.domain.dto;

import lombok.Data;

@Data
public class BankcardDTO {
    private Long fundAccount;
    private String bankcardNumber;
}
