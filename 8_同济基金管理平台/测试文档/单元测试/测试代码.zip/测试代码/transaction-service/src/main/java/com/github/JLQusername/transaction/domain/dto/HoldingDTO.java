package com.github.JLQusername.transaction.domain.dto;

import lombok.Data;

@Data
public class HoldingDTO {
    private long tradingAccountId;
    private int productId;
}
