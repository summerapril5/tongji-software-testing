package com.github.JLQusername.settle.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.JLQusername.api.OurSystem;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SystemMapper extends BaseMapper<OurSystem> {
}
